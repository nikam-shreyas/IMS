import React, { Component } from "react";
import "react-loader-spinner/dist/loader/css/react-spinner-loader.css";
import Loader from "react-loader-spinner";

class Restricted extends Component {
  render() {
    return <h4>Loading...</h4>;
  }
}

export default Restricted;
