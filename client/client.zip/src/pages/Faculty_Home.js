import React, { Fragment } from "react";
import Internships from "../components/internships";

const Faculty_Home = ({ authType, isAthenticated }) => {
  return (
    <Fragment>
      <Internships />
    </Fragment>
  );
};

export default Faculty_Home;